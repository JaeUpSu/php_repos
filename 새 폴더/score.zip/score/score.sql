create table score (
num int not null auto_increment,
name char(12),
sub1 int,
sub2 int,
sub3 int,
sub4 int,
sub5 int,
sum int,
avg float,
primary key(num) )